﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //IAnimal dog = new Dog("Max" "White" , 5);
            //Animal abstractDog = new Dog("Molly", "Brown", 3);
            //dog. EatO;
            //abstractDog.EatO);
            //dog. Speak;

            //Animal cat = new Cat("Mouse" "Black" , 4);
            //cat.EatO;

            ISpeaks speaks = new Dog("MAX", "White", "white", 3);
            speaks.Speaks();
            IEats eats - new Cat("Mouse", "Black", "Black", 4);
            eats.Eat(); 
            List<ISpeaks> speakers = new List<ISpeaks>();
        }
    }
}
