﻿namespace Lab_3
{
    internal interface IAnimal
    {
        int Age { get; set; }
        string Colour { get; set; }
        string Name { get; set; }

        //void Eat();
        //void Speak();
    }
}