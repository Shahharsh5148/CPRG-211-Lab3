﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    internal class Cat
    {
        public Cat(string name, string colour, string v, int age) : base(name, colour, age)
        {

        }
        public  void Eat()
        {
            Console.WriteLine("Cat eat meat");
        }
        public void Speak()
        {
            Console.WriteLine("Meow");
        }
    }
}
