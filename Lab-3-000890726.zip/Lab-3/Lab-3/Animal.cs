﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    internal abstract class Animal : IAnimal
    {
        protected string name;
        protected string colour;
        private int age;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Colour
        {
            get { return colour; }
            set { colour = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        protected Animal(string name, string colour, int age)
        {
            this.name = name;
            this.colour = colour;
            this.age = age;
        }

        //public abstract void Eat();

        //public abstract void Speak();
        
    }
}

        
